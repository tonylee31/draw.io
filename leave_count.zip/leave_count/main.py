from f_read_excel import read_excel_to_json
from datetime import date, datetime
from typing import Union
from pathlib import Path
import pandas as pd
import numpy as np
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, Alignment
import calendar

 
########### Helper Functions ###########    
def parse_to_date(value) -> Union[date, None]:
    """Normalize various date inputs to a `datetime.date` or return None."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    if isinstance(value, datetime):
        return value.date()
    try:
        return pd.to_datetime(value, errors='coerce').date()
    except Exception:
        return None
 
 
def get_holiday_row(target_date, df_holiday_table: pd.DataFrame):
    """Return the row(s) from `df_holiday_table` matching `target_date`.

    `target_date` may be a string, `datetime`, or `date`. Returns a DataFrame
    slice if matches found, otherwise returns `None`.
    """
    d = parse_to_date(target_date)
    if d is None:
        return None
    if df_holiday_table is None or 'Date' not in df_holiday_table.columns:
        return None
    # Convert holiday Date column to date for comparison
    try:
        col_dates = pd.to_datetime(df_holiday_table['Date'], errors='coerce').dt.date
    except Exception:
        return None
    mask = col_dates == d
    # Normalize holiday dates and build fast lookup by date
    df_holiday_table['Date_parsed'] = pd.to_datetime(df_holiday_table['Date'], errors='coerce').dt.date
    df_holiday_table_by_date = df_holiday_table.set_index('Date_parsed')

    # Helper to get holiday row by a date (returns Series or None)
    def get_holiday_row_by_date(att_date: Union[str, date, datetime]) -> Union[pd.Series, None]:
        d = pd.to_datetime(att_date, errors='coerce').date()
        try:
            return df_holiday_table_by_date.loc[d]
        except KeyError:
            return None

    # Example usage:
    # row = get_holiday_row_by_date("2025-10-15")
    # if row is not None:
    #     print("Holiday row:", row)
    if mask.any():
        return df_holiday_table.loc[mask].copy()
    return None
 
 
def is_workday(target_date) -> bool:
    """Return True if `target_date` is a workday (Mon-Fri).

    Saturday and Sunday return False. 
    """
    d = parse_to_date(target_date)
    if d is None:
        raise ValueError(f"Invalid date input: {target_date}")
    # weekday(): 0=Mon ... 5=Sat, 6=Sun
    if d.weekday() >= 5:
        return False
    return True
 
 
def is_skip_am_pm(target_date, df_holiday_table: pd.DataFrame = None) -> dict:
    """Return True if `target_date` is a workday (Mon-Fri and not a holiday).

    Saturday and Sunday return False. If `df_holiday_table` is provided and
    contains a matching holiday row, this also returns False.
    """
    d = parse_to_date(target_date)
    if d is None:
        raise ValueError(f"Invalid date input: {target_date}")
    if df_holiday_table is not None:
        hr = get_holiday_row(d, df_holiday_table)
        if hr is not None and not hr.empty:
        #    if not hr['AM'].empty and hr['AM'].values[0]:
        # 
        #       return hr['AM'].values[0]
           return hr
    return None


def days_in_month(year: int = None, month: int = None) -> int:
        """Return number of days for given year and month.
        Defaults: year -> current year, month -> current_month variable or current month.
        """
        if year is None:
            year = date.today().year
        if month is None:
            month = int(current_month) if 'current_month' in globals() else date.today().month
        try:
            m = int(month)
        except Exception:
            raise ValueError(f"Invalid month value: {month}")
        if not 1 <= m <= 12:
            raise ValueError(f"Month must be in 1..12, got {m}")
        return calendar.monthrange(year, m)[1]

    # Example usage: compute days for the configured current_month
    #current_month_days = days_in_month(year=date.today().year, month=int(current_month))
    #print(f"Days in month {int(current_month)}: {current_month_days}")





# Get the path of the current script
script_path = Path(__file__)

# Get the directory containing the current script
script_directory = script_path.parent





# Only Execute by directly call
if __name__ == "__main__":

    current_year = 2025
    current_month = 10 # Test

    ########### Load Holiday Table ###########
    json_holiday_table = read_excel_to_json(
        excel_path=script_directory / '_config/holiday_table.xlsx',
        #date_cols=['Date', 'Check In', 'Check Out'],
        date_cols=['Date'],
        drop_empty_rows=True,
        date_format="%Y-%m-%d %H:%M:%S",
    )
    #print(json_holiday_table)
    
    #Convert to DataFrame
    df_holiday_table = pd.DataFrame(json_holiday_table)
    #print(df_holiday_table)




    ########### Load Subteam Record ###########
    json_subteam_mapping = read_excel_to_json(
        excel_path=script_directory / '_config' / 'subteam_mapping.xlsx',
        date_cols=[],
        drop_empty_rows=True,
        date_format="%Y-%m-%d",
    )
    #print(json_subteam_mapping)
    
    #Convert to DataFrame
    df_subteam_mapping = pd.DataFrame(json_subteam_mapping)
    #print(df_subteam_mapping)





    ########### Load Input Attendance Record ###########
    json_attendance_record = read_excel_to_json(
        excel_path=script_directory / '_input' / 'attendance_record.xlsx',
        #date_cols=['Date', 'Check In', 'Check Out'],
        date_cols=['Date'],
        drop_empty_rows=True,
        date_format="%Y-%m-%d",
    )
    #print(json_attendance_record)

    # Convert to DataFrame
    df_attendance = pd.DataFrame(json_attendance_record)
    df_attendance['flag_skip_holiday'] = ''         # Flag for that date should be skipped for attendance calculation
    df_attendance['flag_skip_am'] = ''              # Flag for skip count AM day
    df_attendance['flag_skip_pm'] = ''              # Flag for skip count PM day
    df_attendance['flag_early_leave'] = ''          # Flag for early leave time
    df_attendance['flag_am_leave'] = ''             # Flag for AM Leave
    df_attendance['flag_pm_leave'] = ''             # Flag for PM Leave
    df_attendance['flag_am_late'] = ''              # Flag for AM Late
    df_attendance['flag_am_no_show'] = ''           # Flag for AM No Show
    df_attendance['flag_pm_early_leave'] = ''       # Flag for PM early leave
    df_attendance['flag_pm_no_show'] = ''           # Flag for PM No Show
    #print(df_attendance)
    #print(df_attendance.iloc[0])





    ########### Logic : Determinate weekend dates and set flag_skip_holiday ###########
    # Normalize Date to python.date for reliable checks
    df_attendance['Date_parsed'] = pd.to_datetime(df_attendance['Date'], errors='coerce').dt.date
    # Try calling check_weekend on the whole Series; if it fails, fall back to elementwise calls
    try:
        weekday_mask = is_workday(df_attendance['Date_parsed'])
    except Exception:
        weekday_mask = df_attendance['Date_parsed'].apply(lambda d: bool(is_workday(d)))
    # Ensure mask is a Series aligned with the dataframe index
    weekday_mask = pd.Series(weekday_mask, index=df_attendance.index).astype(bool)
    # Set flag_skip_holiday to 1 for weekend dates
    df_attendance.loc[~weekday_mask, 'flag_skip_holiday'] = 'Y'
    # optional: remove helper column
    df_attendance.drop(columns=['Date_parsed'], inplace=True)
    #print (df_attendance)





    ########### Logic : Determinate holiday and set flag_skip_am / flag_skip_pm / flag_early_leave ###########
    df_attendance['Date_parsed'] = pd.to_datetime(df_attendance['Date'], errors='coerce').dt.date
    # Mark skip AM / PM based on holiday table
    df_attendance.loc[:, 'flag_skip_am'] = df_attendance['Date_parsed'].apply(
        lambda d: is_skip_am_pm(d, df_holiday_table)['AM'].values[0] if is_skip_am_pm(d, df_holiday_table) is not None else ''
    )
    df_attendance.loc[:, 'flag_skip_pm'] = df_attendance['Date_parsed'].apply(
        lambda d: is_skip_am_pm(d, df_holiday_table)['PM'].values[0] if is_skip_am_pm(d, df_holiday_table) is not None else ''
    )
    # Mark early leave based on holiday table
    df_attendance.loc[:, 'flag_early_leave'] = df_attendance['Date_parsed'].apply(
        lambda d: is_skip_am_pm(d, df_holiday_table)['Early_Leave'].values[0] if is_skip_am_pm(d, df_holiday_table) is not None else ''
    )
    # optional: remove helper column
    df_attendance.drop(columns=['Date_parsed'], inplace=True)





    ########### Load Input Leave Record ###########
    json_leave_record = read_excel_to_json(
        excel_path=script_directory / '_input' / 'leave_record.xls',
        #date_cols=['Date', 'Check In', 'Check Out'],
        #date_cols=['From', 'To'],
        drop_empty_rows=True,
        date_format="%Y-%m-%d %H:%M:%S",
    )
    #print(json_leave_record)
    # # Convert to DataFrame
    df_leave_record = pd.DataFrame(json_leave_record)
    #print(df_leave_record)


    # Rename 'Staff Code' column to 'staff_code' for both DataFrames (Can't handle manipulate with space name for data columns)
    df_attendance = df_attendance.rename(columns={'Staff Code': 'staff_code'})
    df_leave_record = df_leave_record.rename(columns={'Staff Code': 'staff_code'})
    for row in df_attendance.itertuples(index=True): # index=False if you don't need the index
        # Get leave records for this staff member
        staff_leave_records = df_leave_record[df_leave_record['staff_code'] == row.staff_code]

     
        # Check if the attendance date falls within any leave period
        for leave_row in staff_leave_records.itertuples():
            #print(f"Staff Code: {leave_row.staff_code}, Check Date: {row.Date}, Leave Range: {leave_row.From}, {leave_row.To}")
            leave_from = pd.to_datetime(leave_row.From, errors='coerce').date()
            leave_to = pd.to_datetime(leave_row.To, errors='coerce').date()
            attendance_date = pd.to_datetime(row.Date, errors='coerce').date()
   
            if not pd.isna(leave_from) and not pd.isna(leave_to):
                if leave_from <= attendance_date <= leave_to:
                    #print(f"Match found")

                    # Set AM/PM leave flags as needed
                    if (attendance_date == leave_from):
                        leave_from_time = pd.to_datetime(leave_row.From, errors='coerce').time()
                        if leave_from_time >= datetime.strptime('14:00:00', '%H:%M:%S').time():
                            df_attendance.at[row.Index, 'flag_pm_leave'] = 'Y'
                        else:
                            df_attendance.at[row.Index, 'flag_am_leave'] = 'Y'
                            df_attendance.at[row.Index, 'flag_pm_leave'] = 'Y'
                    elif (attendance_date == leave_to):
                        leave_to_time = pd.to_datetime(leave_row.To, errors='coerce').time()
                        if leave_to_time <= datetime.strptime('13:00:00', '%H:%M:%S').time():
                            df_attendance.at[row.Index, 'flag_am_leave'] = 'Y'
                        else:
                            df_attendance.at[row.Index, 'flag_am_leave'] = 'Y'
                            df_attendance.at[row.Index, 'flag_pm_leave'] = 'Y'
                    else:
                        df_attendance.at[row.Index, 'flag_am_leave'] = 'Y'
                        df_attendance.at[row.Index, 'flag_pm_leave'] = 'Y'
                    break
        




    ########### Logic : Determine AM Late / PM Early Leave / No Show Flags (Initial) ###########
    # Check AM no show
    # Not holiday, Not skip AM, Not AM leave, "First in" is null or >= 13:00:00
    df_attendance['timestamp'] = pd.to_datetime(df_attendance['First in'], format='%H:%M:%S', errors='coerce').dt.time
    df_attendance.loc[
        (df_attendance['flag_skip_holiday'] != 'Y') &
        (df_attendance['flag_skip_am'] != 'Y') &
        (df_attendance['flag_am_leave'] != 'Y') &
        (
            (df_attendance['timestamp'].isnull()) |
            (df_attendance['timestamp'] >= datetime.strptime('13:00:00', '%H:%M:%S').time())
        ),
        'flag_am_no_show'
    ] = 'Y'
    # Remove helper column
    df_attendance.drop(columns=['timestamp'], inplace=True)

    # Check AM late
    # Not holiday, Not skip AM, Not AM leave, "First in" is null or > 09:00:00
    df_attendance['timestamp'] = pd.to_datetime(df_attendance['First in'], format='%H:%M:%S', errors='coerce').dt.time
    df_attendance.loc[
        (df_attendance['flag_am_no_show'] != 'Y') &
        (df_attendance['flag_skip_holiday'] != 'Y') &
        (df_attendance['flag_skip_am'] != 'Y') &
        (df_attendance['flag_am_leave'] != 'Y') &
        (
            (df_attendance['timestamp'].isnull()) |
            (df_attendance['timestamp'] >= datetime.strptime('09:01:00', '%H:%M:%S').time())
        ),
        'flag_am_late'
    ] = 'Y'
    # Remove helper column
    df_attendance.drop(columns=['timestamp'], inplace=True)

    # Check PM no show
    # Not holiday, Not skip PM, Not PM leave, "Last Out" is null or <= 13:00:00
    df_attendance['timestamp'] = pd.to_datetime(df_attendance['Last Out'], format='%H:%M:%S', errors='coerce').dt.time
    df_attendance.loc[
        (df_attendance['flag_skip_holiday'] != 'Y') &
        (df_attendance['flag_skip_pm'] != 'Y') &
        (df_attendance['flag_pm_leave'] != 'Y') &
        (
            (df_attendance['timestamp'].isnull()) |
            (df_attendance['timestamp'] <= datetime.strptime('13:00:00', '%H:%M:%S').time())
        ),
        'flag_pm_no_show'
    ] = 'Y'
     # Remove helper column
    df_attendance.drop(columns=['timestamp'], inplace=True)       
    
    # Check PM early leave
    # Not holiday, Not skip PM, Not PM leave, "Last Out" is null or < 18:00:00
    df_attendance['timestamp'] = pd.to_datetime(df_attendance['Last Out'], format='%H:%M:%S', errors='coerce').dt.time
    df_attendance.loc[
        (df_attendance['flag_pm_no_show'] != 'Y') &
        (df_attendance['flag_skip_holiday'] != 'Y') &
        (df_attendance['flag_skip_pm'] != 'Y') &
        (df_attendance['flag_pm_leave'] != 'Y') &
        (
            (df_attendance['timestamp'].isnull()) |
            (df_attendance['timestamp'] < datetime.strptime('18:00:00', '%H:%M:%S').time())
        ),
        'flag_pm_early_leave'
    ] = 'Y'
     # Remove helper column
    df_attendance.drop(columns=['timestamp'], inplace=True)      

    # Check Company Official Early Leave Override for PM early leave
    # Not holiday, Not skip PM, Not PM leave, "Last Out" >= flag_early_leave
    df_attendance['timestamp'] = pd.to_datetime(df_attendance['Last Out'], format='%H:%M:%S', errors='coerce').dt.time
    df_attendance['timestamp2'] = pd.to_datetime(df_attendance['flag_early_leave'], format='%H:%M:%S', errors='coerce').dt.time
    df_attendance.loc[
        (df_attendance['flag_pm_early_leave'] == 'Y') &
        (
            (df_attendance['timestamp2'].notnull()) |
            (df_attendance['timestamp'] >= df_attendance['timestamp2'])
        ),
        'flag_pm_early_leave'
    ] = ''
     # Remove helper column
    df_attendance.drop(columns=['timestamp'], inplace=True)      
    df_attendance.drop(columns=['timestamp2'], inplace=True)





    ########### Logic : Determine Abnormal Remark / Reason ###########
    df_attendance['Abnormal Remark'] = '' 
    df_attendance['Reason'] = '' 
    # Define Reason Based on Flags
    df_attendance.loc[
        (df_attendance['flag_skip_holiday'] == 'Y'),
        'Reason'
    ] = '星期六/日'
    df_attendance.loc[
        (df_attendance['flag_skip_am'] == 'Y') & (df_attendance['flag_skip_pm'] == 'Y'),
        'Reason'
    ] = '公眾/公司假期'
    df_attendance.loc[
        (df_attendance['flag_skip_am'] == 'Y') & (df_attendance['flag_skip_pm'] != 'Y'),
        'Reason'
    ] = '公司假期(上午) '
    df_attendance.loc[
        (df_attendance['flag_skip_am'] != 'Y') & (df_attendance['flag_skip_pm'] == 'Y'),
        'Reason'
    ] = '公司假期(下午) '
    df_attendance.loc[
        (df_attendance['flag_skip_am'] != 'Y') & (df_attendance['flag_skip_pm'] == 'Y'),
        'Reason'
    ] = '公司假期(下午) '
    df_attendance.loc[
        (df_attendance['flag_skip_holiday'] != 'Y') 
        & (df_attendance['flag_skip_am'] != 'Y') & (df_attendance['flag_am_leave'] == 'Y')
        & (df_attendance['flag_skip_pm'] != 'Y') & (df_attendance['flag_pm_leave'] == 'Y'),
        'Reason'
    ] = df_attendance['Reason'] + 'Leave(全日) '
    df_attendance.loc[
        (df_attendance['flag_skip_holiday'] != 'Y') 
        & (df_attendance['flag_skip_am'] != 'Y') & (df_attendance['flag_am_leave'] == 'Y')
        & (df_attendance['flag_skip_pm'] != 'Y') & (df_attendance['flag_pm_leave'] != 'Y'),
        'Reason'
    ] = df_attendance['Reason'] + 'Leave(上午) '
    df_attendance.loc[
        (df_attendance['flag_skip_holiday'] != 'Y') 
        & (df_attendance['flag_skip_am'] != 'Y') & (df_attendance['flag_am_leave'] != 'Y')
        & (df_attendance['flag_skip_pm'] != 'Y') & (df_attendance['flag_pm_leave'] == 'Y'),
        'Reason'
    ] = df_attendance['Reason'] + 'Leave(下午) '
    # Define Abnormal Remark Based on Flags
    df_attendance.loc[
        (df_attendance['flag_am_no_show'] == 'Y') & (df_attendance['flag_pm_no_show'] == 'Y'),
        'Abnormal Remark'
    ] =  df_attendance['Abnormal Remark'] + '全天缺勤 ' 
    df_attendance.loc[
        (df_attendance['flag_am_no_show'] == 'Y') & (df_attendance['flag_pm_no_show'] != 'Y'),
        'Abnormal Remark'
    ] =  df_attendance['Abnormal Remark'] + '上午缺勤 '
    df_attendance.loc[
        (df_attendance['flag_am_no_show'] != 'Y') & (df_attendance['flag_pm_no_show'] != 'Y')
         & (df_attendance['flag_am_late'] == 'Y'),
        'Abnormal Remark'
    ] =  df_attendance['Abnormal Remark'] + '上午遲到 '
    df_attendance.loc[
        (df_attendance['flag_am_no_show'] != 'Y') & (df_attendance['flag_pm_no_show'] == 'Y'),
        'Abnormal Remark'
    ] =  df_attendance['Abnormal Remark'] + '下午缺勤 '
    df_attendance.loc[
        (df_attendance['flag_am_no_show'] != 'Y') & (df_attendance['flag_pm_no_show'] != 'Y')
         & (df_attendance['flag_pm_early_leave'] == 'Y'),
        'Abnormal Remark'
    ] =  df_attendance['Abnormal Remark'] + '下午早退 '

    # Merge df_attendance with df_subteam_mapping on 'Staff Code'
    df_attendance = df_attendance.rename(columns={'staff_code': 'Staff Code'})
    # Merge df_attendance with df_subteam_mapping on 'Staff Code'
    df_attendance = pd.merge(
        left=df_attendance,
        right=df_subteam_mapping[['Staff Code', 'Team', 'Full Name']],
        on='Staff Code',
        how='left'  # Use 'left' join to keep all records from df_attendance
    )
    #print(df_attendance)




    ########### Logic : Count Leave / Holiday Days per Staff ###########
    # Count full-day skips per staff
    df_attendance['count_holiday'] = (
        (df_attendance.get('flag_skip_holiday', '') == 'Y')
    ).astype(int)
    #print(df_attendance[['Staff Code', 'Date', 'flag_skip_holiday', 'count_holiday']])
    
    # Count AM skips per staff (Exclude full-day skips)
    df_attendance['count_am_holiday'] = (
        ((df_attendance.get('flag_skip_holiday', '') != 'Y') & (df_attendance.get('flag_skip_am', '') == 'Y'))
    ).astype(int)
    #print(df_attendance[['Staff Code', 'Date', 'flag_skip_am', 'count_am_holiday']])

    # Count PM skips per staff (Exclude full-day skips)
    df_attendance['count_pm_holiday'] = (
        ((df_attendance.get('flag_skip_holiday', '') != 'Y') & (df_attendance.get('flag_skip_pm', '') == 'Y'))
    ).astype(int)
    #print(df_attendance[['Staff Code', 'Date', 'flag_skip_pm', 'count_pm_holiday']])

    # Count AM leave per staff (Exclude full-day skips & AM skips)
    df_attendance['count_am_leave'] = (
        ((df_attendance.get('flag_skip_holiday', '') != 'Y') & (df_attendance.get('flag_skip_am', '') != 'Y')
         & (df_attendance.get('flag_am_leave', '') == 'Y'))
    ).astype(int)
    #print(df_attendance[['Staff Code', 'Date', 'flag_am_leave', 'count_am_leave']])

    # Count PM leave per staff (Exclude full-day skips & PM skips)
    df_attendance['count_pm_leave'] = (
        ((df_attendance.get('flag_skip_holiday', '') != 'Y') & (df_attendance.get('flag_skip_pm', '') != 'Y')
         & (df_attendance.get('flag_pm_leave', '') == 'Y'))
    ).astype(int)
    #print(df_attendance[['Staff Code', 'Date', 'flag_pm_leave', 'count_pm_leave']])

    # Count AM proper workdays per staff (Exclude full-day skips, AM skips, AM leaves, AM no-shows, AM lates)
    df_attendance['count_am_workday'] = (
        ((df_attendance.get('flag_skip_holiday', '') != 'Y') & (df_attendance.get('flag_skip_am', '') != 'Y')
            & (df_attendance.get('flag_am_leave', '') != 'Y') & (df_attendance.get('flag_am_no_show', '') != 'Y')
            & (df_attendance.get('flag_am_late', '') != 'Y'))
    ).astype(int)
    #print(df_attendance[['Staff Code', 'Date', 'count_am_workday']])

    # Count PM proper workdays per staff (Exclude full-day skips, PM skips, PM leaves, PM no-shows, PM early leaves)
    # Note: Early leave does not count as leave day
    df_attendance['count_pm_workday'] = (
        ((df_attendance.get('flag_skip_holiday', '') != 'Y') & (df_attendance.get('flag_skip_pm', '') != 'Y')
            & (df_attendance.get('flag_pm_leave', '') != 'Y') & (df_attendance.get('flag_pm_no_show', '') != 'Y')
            & (df_attendance.get('flag_pm_late', '') != 'Y'))
    ).astype(int)
    #print(df_attendance[['Staff Code', 'Date', 'count_pm_workday']])

    # Aggregate counts per staff
    #no_of_days_by_month = days_in_month(year=int(current_year), month=int(current_month))
    no_of_days_by_record = df_attendance.groupby('Staff Code')['Date'].count()
    no_of_holiday = df_attendance.groupby('Staff Code')['count_holiday'].sum()
    no_of_am_holiday = df_attendance.groupby('Staff Code')['count_am_holiday'].sum()
    no_of_pm_holiday = df_attendance.groupby('Staff Code')['count_pm_holiday'].sum()
    no_of_am_leave = df_attendance.groupby('Staff Code')['count_am_leave'].sum()
    no_of_pm_leave = df_attendance.groupby('Staff Code')['count_pm_leave'].sum()
    no_of_am_workday = df_attendance.groupby('Staff Code')['count_am_workday'].sum()
    no_of_pm_workday = df_attendance.groupby('Staff Code')['count_pm_workday'].sum()
    no_of_workday = no_of_am_workday * 0.5 + no_of_pm_workday * 0.5
    
    # Combine attendance counts into a single DataFrame grouped by staff
    df_attendance_summary = pd.DataFrame({
        'Full Day': no_of_holiday,
        'AM Only': no_of_am_holiday,
        'PM Only': no_of_pm_holiday,
        'AM Leave': no_of_am_leave,
        'PM Leave': no_of_pm_leave,
        'AM Workday': no_of_am_workday,
        'PM Workday': no_of_pm_workday,
        'Normal Workday': no_of_workday,
        'Total Days': no_of_days_by_record,
    })
    #for staff, count in no_of_holiday.items():
    #    print(f"Staff {staff}: full-day skipped dates = {int(count)}")
   
    df_attendance_summary['Total Leave Days'] = (
        df_attendance_summary['Full Day'] +
        (df_attendance_summary['AM Only'] * 0.5) +
        (df_attendance_summary['PM Only'] * 0.5) +
        (df_attendance_summary['AM Leave'] * 0.5) +
        (df_attendance_summary['PM Leave'] * 0.5)
    )

    # Calculate the Attendance Percent
    df_attendance_summary['Attendance Percent'] = (
        (df_attendance_summary['Normal Workday'])
        / (df_attendance_summary['Total Days'] - df_attendance_summary['Total Leave Days'])
    ) * 100.0

    # Merge df_attendance_summary with df_subteam_mapping on 'Staff Code'
    df_attendance_summary = pd.merge(
        left=df_attendance_summary,
        right=df_subteam_mapping[['Staff Code', 'Team', 'Full Name']],
        on='Staff Code',
        how='left'  # Use 'left' join to keep all records from df_attendance
    )
    print(df_attendance_summary[['Staff Code', 'AM Workday', 'PM Workday', 'Total Days', 'Total Leave Days', 'Normal Workday', 'Attendance Percent']])
    #print(df_attendance_summary)




    # Build a team-level listing of staff with attendance percent
    # Build team summary with a summary row before each team's members
    df_team_summary = (
        df_attendance_summary[['Team', 'Staff Code', 'Full Name', 'Attendance Percent']]
        .copy()
        .sort_values(['Team', 'Staff Code'])
        .reset_index(drop=True)
    )

    # Ensure Team column has no missing values for grouping
    df_team_summary['Team'] = df_team_summary['Team'].fillna('')

    parts = []
    for team, grp in df_team_summary.groupby('Team', sort=True):
        # compute team-level attendance percent (mean); change to sum if desired
        team_att_pct = grp['Attendance Percent'].mean()
        # create summary row (placed before the group's rows)
        summary_row = pd.DataFrame([{
            'Team': team,
            'Staff Code': f'{team} Summary',
            'Full Name': '',
            'Attendance Percent': round(team_att_pct, 2)
        }])
        parts.append(summary_row)
        parts.append(grp)

   


    df_team_summary = pd.concat(parts, ignore_index=True)
    df_team_summary['Attendance Percent'] = round(df_team_summary['Attendance Percent'], 2).astype(str) + '%'

    print("Team summary (sample):")
    print(df_team_summary.head(20))


    # Save team summary to Excel
    output_dir = script_directory / '_output'
    output_dir.mkdir(parents=True, exist_ok=True)
    team_output_path = output_dir / 'team_summary_output.xlsx'

    sheet_name = 'Team Summary'
    title_text = f"Team Summary - Generated {date.today().isoformat()}"
    ncols = len(df_team_summary.columns) if df_team_summary is not None else 1

    with pd.ExcelWriter(team_output_path, engine='openpyxl') as writer:
        df_team_summary.to_excel(writer, index=False, startrow=1, sheet_name=sheet_name)
        workbook = writer.book
        worksheet = writer.sheets[sheet_name]

        # Merge first row across all dataframe columns and set title
        worksheet.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
        title_cell = worksheet.cell(row=1, column=1)
        title_cell.value = title_text
        title_cell.font = Font(size=14, bold=True)
        title_cell.alignment = Alignment(horizontal='center', vertical='center')
        worksheet.row_dimensions[1].height = 20



    print("Team summary saved to:", team_output_path)







    ########### Output to Excel ###########
    # Ensure output directory exists and write with a merged-title top row
    output_dir = script_directory / '_output'
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / 'attendance_record_output.xlsx'

    sheet_name = 'Attendance'
    title_text = f"Attendance Record - Generated {date.today().isoformat()}"

    ncols = len(df_attendance.columns) if df_attendance is not None else 1

    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        df_attendance.to_excel(writer, index=False, startrow=1, sheet_name=sheet_name)
        workbook = writer.book
        worksheet = writer.sheets[sheet_name]

        # Merge first row across all dataframe columns and set title
        worksheet.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
        title_cell = worksheet.cell(row=1, column=1)
        title_cell.value = title_text
        title_cell.font = Font(size=14, bold=True)
        title_cell.alignment = Alignment(horizontal='center', vertical='center')
        worksheet.row_dimensions[1].height = 24

        # Insert one blank row after the title row
        worksheet.insert_rows(2, amount=1)

        # Insert a row for the subtitle 
        worksheet.insert_rows(3, amount=1)
        subtitle_cell = worksheet.cell(row=3, column=1)
        subtitle_cell.value = "HKTESTESTSETSETSETESTSETESTSETESTSTSETIT"
        subtitle_cell.font = Font(size=12, bold=False)
        subtitle_cell.alignment = Alignment(horizontal='center', vertical='center')
        worksheet.row_dimensions[3].height = 14

        # Insert a row for the subtitle 
        worksheet.insert_rows(4, amount=1)
        subtitle_cell = worksheet.cell(row=4, column=1)
        subtitle_cell.value = "TEsTTESTETETETETSETESTSTEST"
        subtitle_cell.font = Font(size=12, bold=False)
        subtitle_cell.alignment = Alignment(horizontal='center', vertical='center')
        worksheet.row_dimensions[3].height = 14

        # Insert one blank row after the title row
        worksheet.insert_rows(5, amount=1)


    print("Attendance Report processing completed. Output saved to:", output_path)

 
 



    ########### Output to Excel ###########
    # Ensure output directory exists and write with a merged-title top row
    output_dir = script_directory / '_output'
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / 'attendance_percent_output.xlsx'

    sheet_name = 'Attendance'
    title_text = f"Attendance Percent Record - Generated {date.today().isoformat()}"

    ncols = len(df_attendance_summary.columns) if df_attendance_summary is not None else 1

    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        df_attendance_summary.to_excel(writer, index=False, startrow=1, sheet_name=sheet_name)
        workbook = writer.book
        worksheet = writer.sheets[sheet_name]

        # Merge first row across all dataframe columns and set title
        worksheet.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
        title_cell = worksheet.cell(row=1, column=1)
        title_cell.value = title_text
        title_cell.font = Font(size=14, bold=True)
        title_cell.alignment = Alignment(horizontal='center', vertical='center')
        worksheet.row_dimensions[1].height = 24

        # Insert one blank row after the title row
        worksheet.insert_rows(2, amount=1)

        # Insert a row for the subtitle 
        worksheet.insert_rows(3, amount=1)
        subtitle_cell = worksheet.cell(row=3, column=1)
        subtitle_cell.value = "HKTESTESTSETSETSETESTSETESTSETESTSTSETIT"
        subtitle_cell.font = Font(size=12, bold=False)
        subtitle_cell.alignment = Alignment(horizontal='center', vertical='center')
        worksheet.row_dimensions[3].height = 14

        # Insert a row for the subtitle 
        worksheet.insert_rows(4, amount=1)
        subtitle_cell = worksheet.cell(row=4, column=1)
        subtitle_cell.value = "TEsTTESTETETETETSETESTSTEST"
        subtitle_cell.font = Font(size=12, bold=False)
        subtitle_cell.alignment = Alignment(horizontal='center', vertical='center')
        worksheet.row_dimensions[3].height = 14

        # Insert one blank row after the title row
        worksheet.insert_rows(5, amount=1)


    print("Attendance Percent Report processing completed. Output saved to:", output_path)