from __future__ import annotations
import json
from pathlib import Path
from typing import Iterable, List, Optional, Any
import pandas as pd
import argparse

"""
f_read_attendance.py

Utility to read an Excel file and store contents as JSON.

Provides:
- read_excel_to_json(...) -> list[dict] or writes JSON file
- CLI for quick use

Example:
    python f_read_attendance.py /path/to/input.xlsx /path/to/output.json --sheet 0 --date-cols Date
"""



def read_excel_to_json(
    excel_path: str | Path,
    json_path: Optional[str | Path] = None,
    sheet_name: Optional[int | str] = 0,
    date_cols: Optional[Iterable[str]] = None,
    drop_empty_rows: bool = False,
    date_format: Optional[str] = None,
    orient: str = "records",
    indent: int = 2,
    ensure_ascii: bool = False,
) -> List[dict] | None:
    """
    Read an Excel sheet and return or save JSON.

    Parameters:
    - excel_path: path to the Excel file.
    - json_path: if provided, write JSON to this path; otherwise return the list of records.
    - sheet_name: sheet index or name passed to pandas.read_excel.
    - date_cols: iterable of column names to parse as dates (optional).
    - drop_empty_rows: drop rows that are completely empty.
    - date_format: strftime format to convert dates to strings (e.g. "%Y-%m-%dT%H:%M:%S").
                   If None, pandas timestamps are converted to ISO format strings.
    - orient: passed to DataFrame.to_dict (default "records").
    - indent, ensure_ascii: passed to json.dump for file output.

    Returns:
    - list of dicts (records) if json_path is None; otherwise returns None after writing file.
    """
    excel_path = Path(excel_path)
    if not excel_path.exists():
        raise FileNotFoundError(f"Excel file not found: {excel_path}")

    # Read
    df = pd.read_excel(excel_path, sheet_name=sheet_name, parse_dates=list(date_cols) if date_cols else None)

    # Optional: drop fully empty rows
    if drop_empty_rows:
        df = df.dropna(how="all")

    # Convert date columns to formatted strings or ISO strings
    if date_cols:
        for col in date_cols:
            if col in df.columns:
                # handle NaT
                if date_format:
                    df[col] = df[col].dt.strftime(date_format)
                else:
                    # ISO format, keep None for NaT
                    df[col] = df[col].apply(lambda x: x.isoformat() if pd.notnull(x) else None)

    # Replace NaN with None for JSON compatibility
    df = df.where(pd.notnull(df), None)

    records = df.to_dict(orient=orient)

    if json_path:
        json_path = Path(json_path)
        json_path.parent.mkdir(parents=True, exist_ok=True)
        with json_path.open("w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=ensure_ascii, indent=indent)
        return None

    return records


def _main():
    p = argparse.ArgumentParser(description="Read Excel and save as JSON")
    p.add_argument("excel", help="Path to Excel file")
    p.add_argument("json", nargs="?", help="Output JSON file (if omitted, prints to stdout)")
    p.add_argument("--sheet", default=0, help="Sheet name or index (default 0)")
    p.add_argument("--date-cols", nargs="*", help="Columns to parse/format as dates", default=None)
    p.add_argument("--drop-empty-rows", action="store_true", help="Drop rows that are completely empty")
    p.add_argument("--date-format", help="strftime for dates (e.g. %%Y-%%m-%%d). If omitted, ISO format used.")
    args = p.parse_args()

    result = read_excel_to_json(
        args.excel,
        json_path=args.json,
        sheet_name=int(args.sheet) if str(args.sheet).isdigit() else args.sheet,
        date_cols=args.date_cols,
        drop_empty_rows=args.drop_empty_rows,
        date_format=args.date_format,
    )

    if result is not None:
        # print JSON to stdout
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    _main()